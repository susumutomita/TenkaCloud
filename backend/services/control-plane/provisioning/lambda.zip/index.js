"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handler.ts
var handler_exports = {};
__export(handler_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(handler_exports);
var import_client_eventbridge = require("@aws-sdk/client-eventbridge");
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");

// ../../shared/events/src/types.ts
var EventDetailType = {
  TENANT_ONBOARDING: "TenantOnboarding",
  TENANT_PROVISIONED: "TenantProvisioned",
  TENANT_UPDATED: "TenantUpdated",
  TENANT_OFFBOARDING: "TenantOffboarding"
};
var EventSource = {
  CONTROL_PLANE: "tenkacloud.control-plane",
  APPLICATION_PLANE: "tenkacloud.application-plane"
};

// src/handler.ts
var eventBridge = new import_client_eventbridge.EventBridgeClient({
  ...process.env.AWS_ENDPOINT_URL ? { endpoint: process.env.AWS_ENDPOINT_URL } : {}
});
var dynamoClient = new import_client_dynamodb.DynamoDBClient({
  ...process.env.DYNAMODB_ENDPOINT ? { endpoint: process.env.DYNAMODB_ENDPOINT } : {}
});
var docClient = import_lib_dynamodb.DynamoDBDocumentClient.from(dynamoClient);
var EVENT_BUS_NAME = process.env.EVENT_BUS_NAME ?? "default";
var DYNAMODB_TABLE = process.env.DYNAMODB_TABLE ?? "TenkaCloud";
async function handler(event) {
  console.log("Processing DynamoDB Stream event", {
    recordCount: event.Records.length
  });
  for (const record of event.Records) {
    try {
      await processRecord(record);
    } catch (error) {
      console.error("Error processing record", {
        eventId: record.eventID,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
}
async function processRecord(record) {
  const eventName = record.eventName;
  if (!eventName || !record.dynamodb) {
    console.log("Skipping record: missing eventName or dynamodb data");
    return;
  }
  const newImage = record.dynamodb.NewImage ? (0, import_util_dynamodb.unmarshall)(
    record.dynamodb.NewImage
  ) : null;
  const oldImage = record.dynamodb.OldImage ? (0, import_util_dynamodb.unmarshall)(
    record.dynamodb.OldImage
  ) : null;
  const pk = newImage?.PK ?? oldImage?.PK;
  const sk = newImage?.SK ?? oldImage?.SK;
  if (!pk?.startsWith("TENANT#") || sk !== "METADATA") {
    console.log("Skipping non-tenant record", { pk, sk });
    return;
  }
  const tenantId = pk.replace("TENANT#", "");
  let eventType;
  switch (eventName) {
    case "INSERT":
      eventType = "TenantOnboarding";
      await updateProvisioningStatus(tenantId, "IN_PROGRESS", "PENDING");
      break;
    case "MODIFY":
      if (oldImage?.status !== newImage?.status) {
        if (newImage?.status === "DELETED") {
          eventType = "TenantOffboarding";
        } else {
          eventType = "TenantUpdated";
        }
      } else if (oldImage?.tier !== newImage?.tier) {
        eventType = "TenantUpdated";
      } else {
        console.log("Skipping MODIFY: no actionable changes");
        return;
      }
      break;
    case "REMOVE":
      eventType = "TenantOffboarding";
      break;
    default:
      console.log("Skipping unknown event type", { eventName });
      return;
  }
  const tenantData = newImage ?? oldImage;
  if (!tenantData) {
    console.error("No tenant data available");
    return;
  }
  const eventDetail = eventType === EventDetailType.TENANT_ONBOARDING ? {
    tenantId,
    tenantName: tenantData.name,
    slug: tenantData.slug,
    tier: tenantData.tier,
    adminEmail: tenantData.adminEmail,
    isolationModel: tenantData.isolationModel,
    region: tenantData.region,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  } : {
    tenantId,
    tenantSlug: tenantData.slug,
    tenantTier: tenantData.tier,
    eventType,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    details: {
      id: tenantData.id,
      name: tenantData.name,
      slug: tenantData.slug,
      tier: tenantData.tier,
      status: tenantData.status,
      auth0OrganizationId: tenantData.auth0OrganizationId
    }
  };
  await publishEvent(eventType, eventDetail);
  console.log("Published tenant event", {
    tenantId,
    eventType,
    tier: tenantData.tier,
    status: tenantData.status
  });
}
async function publishEvent(detailType, detail) {
  const command = new import_client_eventbridge.PutEventsCommand({
    Entries: [
      {
        EventBusName: EVENT_BUS_NAME,
        Source: EventSource.CONTROL_PLANE,
        DetailType: detailType,
        Detail: JSON.stringify(detail)
      }
    ]
  });
  const response = await eventBridge.send(command);
  if (response.FailedEntryCount && response.FailedEntryCount > 0) {
    const failedEntry = response.Entries?.find((e) => e.ErrorCode);
    throw new Error(
      `Failed to publish event: ${failedEntry?.ErrorCode} - ${failedEntry?.ErrorMessage}`
    );
  }
}
async function updateProvisioningStatus(tenantId, status, expectedCurrentStatus) {
  const conditionParts = ["attribute_exists(PK)"];
  const expressionValues = {
    ":status": status,
    ":updatedAt": (/* @__PURE__ */ new Date()).toISOString()
  };
  if (expectedCurrentStatus) {
    conditionParts.push("provisioningStatus = :expectedStatus");
    expressionValues[":expectedStatus"] = expectedCurrentStatus;
  }
  const command = new import_lib_dynamodb.UpdateCommand({
    TableName: DYNAMODB_TABLE,
    Key: {
      PK: `TENANT#${tenantId}`,
      SK: "METADATA"
    },
    UpdateExpression: "SET provisioningStatus = :status, updatedAt = :updatedAt",
    ExpressionAttributeValues: expressionValues,
    ConditionExpression: conditionParts.join(" AND ")
  });
  try {
    await docClient.send(command);
    console.log("Updated provisioning status", { tenantId, status });
  } catch (error) {
    if (error instanceof Error && error.name === "ConditionalCheckFailedException") {
      console.log(
        "Tenant no longer exists or status already updated, skipping",
        { tenantId, status }
      );
      return;
    }
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
